import React, { useState } from 'react';
import { Instagram, Star, ChevronLeft, ChevronRight, ArrowLeft, ChevronDown, ChevronUp, Paperclip } from 'lucide-react';

function App() {
  const [activeTab, setActiveTab] = useState('Strona główna');
  const [currentReviewIndex, setCurrentReviewIndex] = useState(0);
  const [showOpinionForm, setShowOpinionForm] = useState(false);
  const [showContactForm, setShowContactForm] = useState(false);
  const [opinionForm, setOpinionForm] = useState({
    name: '',
    email: '',
    content: ''
  });
  const [expandedFAQ, setExpandedFAQ] = useState<number | null>(null);
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
    agreeToTerms: false
  });

  const handleTikTokClick = () => {
    window.open('https://www.tiktok.com/@_knowek_', '_blank');
  };

  const handleDiscordClick = () => {
    window.open('https://discord.gg/4cYc2BPH', '_blank');
  };

  const handleNavClick = (item: string) => {
    setActiveTab(item);
    setShowOpinionForm(false);
    setShowContactForm(false);
    
    if (item === 'Oferta') {
      const aboutSection = document.getElementById('about-section');
      if (aboutSection) {
        aboutSection.scrollIntoView({ 
          behavior: 'smooth',
          block: 'start'
        });
      }
    } else if (item === 'Opinie') {
      const reviewsSection = document.getElementById('reviews-section');
      if (reviewsSection) {
        reviewsSection.scrollIntoView({ 
          behavior: 'smooth',
          block: 'start'
        });
      }
    } else if (item === 'FAQ') {
      const faqSection = document.getElementById('faq-section');
      if (faqSection) {
        faqSection.scrollIntoView({ 
          behavior: 'smooth',
          block: 'start'
        });
      }
    } else if (item === 'Kontakt') {
      setShowContactForm(true);
    } else if (item === 'Strona główna') {
      window.scrollTo({ 
        top: 0, 
        behavior: 'smooth' 
      });
    }
  };

  const handleOpinionClick = () => {
    setShowOpinionForm(true);
    setActiveTab('');
  };

  const handleBackToReviews = () => {
    setShowOpinionForm(false);
    setActiveTab('Opinie');
  };

  const handleBackToMain = () => {
    setShowContactForm(false);
    setActiveTab('Strona główna');
  };

  const handleContactClick = () => {
    setShowContactForm(true);
    setActiveTab('');
  };

  const handleFormChange = (field: string, value: string) => {
    setOpinionForm(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleContactFormChange = (field: string, value: string | boolean) => {
    setContactForm(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmitOpinion = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Dodaj nową opinię do listy
    const newReview = {
      name: opinionForm.name,
      rating: 5,
      comment: opinionForm.content,
      date: "Teraz"
    };
    
    // Dodaj opinię na początek listy
    setReviews(prev => [newReview, ...prev]);
    
    // Wyczyść formularz
    setOpinionForm({ name: '', email: '', content: '' });
    
    // Pokaż komunikat
    alert('Dziękujemy za opinię!');
    
    // Automatycznie przenieś na stronę główną
    setShowOpinionForm(false);
    setActiveTab('Strona główna');
    setCurrentReviewIndex(0); // Pokaż pierwszą stronę opinii (z nową opinią)
    
    // Przewiń na górę strony
    window.scrollTo({ 
      top: 0, 
      behavior: 'smooth' 
    });
  };

  const handleSubmitContact = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!contactForm.agreeToTerms) {
      alert('Musisz zaakceptować warunki, aby wysłać wiadomość.');
      return;
    }
    
    // Przygotuj dane do wysłania
    const emailData = {
      to: 'wspolpracaknowek@gmail.com',
      subject: `Nowa wiadomość od ${contactForm.name}: ${contactForm.subject}`,
      body: `
Imię i nazwisko: ${contactForm.name}
Email: ${contactForm.email}
Temat: ${contactForm.subject}

Wiadomość:
${contactForm.message}
      `
    };
    
    // Otwórz klienta email z przygotowaną wiadomością
    const mailtoLink = `mailto:${emailData.to}?subject=${encodeURIComponent(emailData.subject)}&body=${encodeURIComponent(emailData.body)}`;
    window.open(mailtoLink, '_blank');
    
    // Pokaż komunikat
    alert('Otwieramy Twojego klienta email z przygotowaną wiadomością!');
    
    // Wyczyść formularz
    setContactForm({
      name: '',
      email: '',
      subject: '',
      message: '',
      agreeToTerms: false
    });
  };

  const toggleFAQ = (index: number) => {
    setExpandedFAQ(expandedFAQ === index ? null : index);
  };

  const handleEmailProvider = (provider: string) => {
    const email = 'wspolpracaknowek@gmail.com';
    let url = '';
    
    switch (provider) {
      case 'gmail':
        url = `https://mail.google.com/mail/?view=cm&fs=1&to=${email}`;
        break;
      case 'onet':
        url = `https://poczta.onet.pl/napisz-wiadomosc?to=${email}`;
        break;
      case 'outlook':
        url = `https://outlook.live.com/mail/0/deeplink/compose?to=${email}`;
        break;
    }
    
    window.open(url, '_blank');
  };

  const navItems = ['Strona główna', 'Oferta', 'Opinie', 'FAQ', 'Kontakt'];

  const [reviews, setReviews] = useState([
    {
      name: "Mateusz K.",
      rating: 5,
      comment: "Świetne treści! _knowek_ ma niesamowity talent do wyjaśniania skomplikowanych rzeczy w prosty sposób. Jego budowle w Minecraft to prawdziwe dzieła sztuki!",
      date: "2 dni temu"
    },
    {
      name: "Anna W.",
      rating: 5,
      comment: "Bardzo inspirujące treści edukacyjne. Dzięki _knowek_ nauczyłam się wielu ciekawych rzeczy. Polecam każdemu, kto lubi łączyć naukę z rozrywką!",
      date: "1 tydzień temu"
    },
    {
      name: "Jakub M.",
      rating: 5,
      comment: "Autentyczny twórca z pasją. Widać, że _knowek_ naprawdę kocha to co robi. Jego społeczność na Discord to świetne miejsce do dyskusji!",
      date: "2 tygodnie temu"
    },
    {
      name: "Karolina S.",
      rating: 5,
      comment: "Fantastyczne treści! _knowek_ potrafi w ciekawy sposób przedstawić nawet najtrudniejsze tematy. Jego kreatywność w Minecraft jest niesamowita!",
      date: "3 tygodnie temu"
    },
    {
      name: "Tomasz L.",
      rating: 5,
      comment: "Jeden z najlepszych twórców edukacyjnych! Treści są zawsze przemyślane i wartościowe. Polecam wszystkim, którzy chcą się uczyć bawiąc się!",
      date: "1 miesiąc temu"
    },
    {
      name: "Magdalena P.",
      rating: 5,
      comment: "Uwielbiam oglądać treści _knowek_! Zawsze dowiaduję się czegoś nowego. Jego budowle w Minecraft to prawdziwe arcydzieła architektury!",
      date: "1 miesiąc temu"
    }
  ]);

  const faqData = [
    {
      question: "Jakie technologie wykorzystujesz najczęściej?",
      answer: "W swoich projektach najczęściej używam nowoczesnych technologii webowych jak React, TypeScript, Node.js oraz narzędzi do budowania w Minecraft. Staram się być na bieżąco z najnowszymi trendami technologicznymi i dzielić się tą wiedzą ze swoją społecznością."
    },
    {
      question: "Czy realizujesz także projekty na zamówienie?",
      answer: "Tak! Realizuję różnego rodzaju projekty na zamówienie - od budowli w Minecraft, przez treści edukacyjne, aż po współprace z markami. Jeśli masz ciekawy pomysł na współpracę, napisz na wspolpracaknowek@gmail.com i omówimy szczegóły."
    },
    {
      question: "Czy pomagasz również w utrzymaniu i rozwoju istniejących projektów?",
      answer: "Oczywiście! Pomagam w rozwoju i utrzymaniu projektów, szczególnie tych związanych z edukacją i gamingiem. Oferuję wsparcie techniczne, konsultacje oraz długoterminową współpracę przy rozwijaniu projektów."
    }
  ];

  const reviewsPerPage = 3;
  const totalPages = Math.ceil(reviews.length / reviewsPerPage);
  const canGoNext = currentReviewIndex < totalPages - 1;
  const canGoPrev = currentReviewIndex > 0;

  const nextReviews = () => {
    if (canGoNext) {
      setCurrentReviewIndex(currentReviewIndex + 1);
    }
  };

  const prevReviews = () => {
    if (canGoPrev) {
      setCurrentReviewIndex(currentReviewIndex - 1);
    }
  };

  const getCurrentReviews = () => {
    const startIndex = currentReviewIndex * reviewsPerPage;
    return reviews.slice(startIndex, startIndex + reviewsPerPage);
  };

  // Jeśli pokazujemy formularz kontaktowy
  if (showContactForm) {
    return (
      <div className="relative bg-gradient-to-br from-gray-900 via-black to-gray-900 min-h-screen">
        {/* Animated stars background - fixed */}
        <div className="fixed inset-0 overflow-hidden">
          <div className="stars"></div>
          <div className="stars2"></div>
          <div className="stars3"></div>
        </div>
        
        {/* Additional cosmic elements - darker - fixed */}
        <div className="fixed inset-0 bg-gradient-to-tr from-transparent via-gray-800/5 to-gray-600/10"></div>
        
        {/* Contact Display */}
        <div className="relative z-10 min-h-screen flex items-center justify-center p-8">
          <div className="bg-gray-800/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-gray-700/50 p-12 max-w-md w-full">
            <div className="flex flex-col items-center space-y-8">
              <h2 className="text-3xl font-bold text-white text-center">
                Kontakt
              </h2>
              
              <div className="text-center space-y-6 w-full">
                <p className="text-gray-300 text-lg">
                  Napisz do mnie na:
                </p>
                
                <div className="bg-gray-700/50 rounded-xl p-6 border border-gray-600/50">
                  <p className="text-white font-semibold text-xl">
                    wspolpracaknowek@gmail.com
                  </p>
                </div>
                
                <div className="space-y-4">
                  <p className="text-gray-300 text-sm">
                    Wybierz swojego dostawcę email:
                  </p>
                  
                  {/* Email provider buttons */}
                  <div className="space-y-3">
                    <button
                      onClick={() => handleEmailProvider('gmail')}
                      className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-xl font-semibold hover:from-red-600 hover:to-red-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
                    >
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M24 5.457v13.909c0 .904-.732 1.636-1.636 1.636h-3.819V11.73L12 16.64l-6.545-4.91v9.273H1.636A1.636 1.636 0 0 1 0 19.366V5.457c0-.904.732-1.636 1.636-1.636h.273L12 10.91l10.091-7.09h.273c.904 0 1.636.732 1.636 1.636z"/>
                      </svg>
                      Gmail
                    </button>
                    
                    <button
                      onClick={() => handleEmailProvider('onet')}
                      className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-xl font-semibold hover:from-orange-600 hover:to-orange-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
                    >
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                      </svg>
                      Onet
                    </button>
                    
                    <button
                      onClick={() => handleEmailProvider('outlook')}
                      className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl font-semibold hover:from-blue-600 hover:to-blue-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
                    >
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M7.88 12.04q0 .45-.11.87-.1.41-.33.74-.22.33-.58.52-.37.2-.87.2t-.85-.2q-.35-.21-.57-.55-.22-.33-.33-.75-.1-.42-.1-.83 0-.43.1-.85.11-.41.33-.74.22-.32.57-.52.36-.2.85-.2t.87.2q.36.2.58.52.22.33.33.74.11.42.11.85zM24 12v9.38q0 .46-.33.8-.33.32-.8.32H7.13q-.46 0-.8-.33-.32-.33-.32-.8V18H1q-.41 0-.7-.3-.3-.29-.3-.7V7q0-.41.3-.7Q.58 6 1 6h6.5L9 4.4q.11-.4.5-.7.4-.3.9-.3H14q.41 0 .7.3.3.29.3.7v1.4q0 .41-.3.7-.29.3-.7.3h-3.6l-.9 1.6H7.13q-.46 0-.8.33-.32.33-.32.8V12H24z"/>
                      </svg>
                      Outlook
                    </button>
                  </div>
                </div>
                
                <p className="text-gray-400 text-sm">
                  Odpowiem najszybciej jak to możliwe!
                </p>
              </div>
              
              {/* Back to main button in bottom right */}
              <div className="w-full flex justify-end mt-8">
                <button
                  onClick={handleBackToMain}
                  className="px-8 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-xl font-semibold hover:from-green-600 hover:to-emerald-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
                >
                  Wróć do strony głównej
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Floating cosmic particles - fixed */}
        <div className="fixed inset-0 pointer-events-none">
          <div className="cosmic-particle"></div>
          <div className="cosmic-particle delay-1000"></div>
          <div className="cosmic-particle delay-2000"></div>
          <div className="cosmic-particle delay-3000"></div>
        </div>
      </div>
    );
  }

  // Jeśli pokazujemy formularz opinii
  if (showOpinionForm) {
    return (
      <div className="relative bg-gradient-to-br from-gray-900 via-black to-gray-900 min-h-screen">
        {/* Animated stars background - fixed */}
        <div className="fixed inset-0 overflow-hidden">
          <div className="stars"></div>
          <div className="stars2"></div>
          <div className="stars3"></div>
        </div>
        
        {/* Additional cosmic elements - darker - fixed */}
        <div className="fixed inset-0 bg-gradient-to-tr from-transparent via-gray-800/5 to-gray-600/10"></div>
        
        {/* Opinion Form */}
        <div className="relative z-10 min-h-screen flex items-center justify-center p-8">
          <div className="bg-gray-800/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-gray-700/50 p-12 max-w-2xl w-full">
            {/* Back button */}
            <button
              onClick={handleBackToReviews}
              className="flex items-center gap-2 text-gray-300 hover:text-white transition-colors duration-300 mb-8"
            >
              <ArrowLeft className="w-5 h-5" />
              Powrót do opinii
            </button>
            
            <div className="flex flex-col space-y-8">
              <h2 className="text-3xl font-bold text-white text-center">
                Podziel się swoją opinią
              </h2>
              
              <form onSubmit={handleSubmitOpinion} className="space-y-6">
                {/* Nazwa */}
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                    Nazwa
                  </label>
                  <input
                    type="text"
                    id="name"
                    value={opinionForm.name}
                    onChange={(e) => handleFormChange('name', e.target.value)}
                    required
                    className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                    placeholder="Twoje imię lub pseudonim"
                  />
                </div>
                
                {/* Email */}
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    value={opinionForm.email}
                    onChange={(e) => handleFormChange('email', e.target.value)}
                    required
                    className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                    placeholder="twoj@email.com"
                  />
                </div>
                
                {/* Treść */}
                <div>
                  <label htmlFor="content" className="block text-sm font-medium text-gray-300 mb-2">
                    Treść opinii
                  </label>
                  <textarea
                    id="content"
                    value={opinionForm.content}
                    onChange={(e) => handleFormChange('content', e.target.value)}
                    required
                    rows={6}
                    className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 resize-none"
                    placeholder="Podziel się swoją opinią o moich treściach..."
                  />
                </div>
                
                {/* Submit button */}
                <button
                  type="submit"
                  className="w-full px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl font-semibold hover:from-blue-600 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
                >
                  Wyślij opinię
                </button>
              </form>
              
              <div className="text-center text-gray-400 text-sm">
                <p>Twoja opinia pomoże mi tworzyć lepsze treści!</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Floating cosmic particles - fixed */}
        <div className="fixed inset-0 pointer-events-none">
          <div className="cosmic-particle"></div>
          <div className="cosmic-particle delay-1000"></div>
          <div className="cosmic-particle delay-2000"></div>
          <div className="cosmic-particle delay-3000"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative bg-gradient-to-br from-gray-900 via-black to-gray-900">
      {/* Top Navigation */}
      <nav className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 bg-gray-900/95 backdrop-blur-sm border border-gray-700/50 rounded-2xl">
        <div className="px-6">
          <div className="flex items-center justify-center h-12">
            <div className="flex space-x-2">
              {navItems.map((item) => (
                <button
                  key={item}
                  onClick={() => handleNavClick(item)}
                  className={`px-4 py-2 text-sm font-medium transition-all duration-200 rounded-xl ${
                    activeTab === item
                      ? 'bg-gray-800 text-white shadow-lg'
                      : 'text-white hover:text-gray-300 hover:bg-gray-800/50'
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Animated stars background - fixed */}
      <div className="fixed inset-0 overflow-hidden">
        <div className="stars"></div>
        <div className="stars2"></div>
        <div className="stars3"></div>
      </div>
      
      {/* Additional cosmic elements - darker - fixed */}
      <div className="fixed inset-0 bg-gradient-to-tr from-transparent via-gray-800/5 to-gray-600/10"></div>
      
      {/* First section - Main content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-8 pt-24">
        <div className="bg-gray-800/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-gray-700/50 p-12 max-w-md w-full">
          <div className="flex flex-col items-center space-y-8">
            {/* Discord-style profile header */}
            <div className="flex items-center space-x-4 mb-4">
              <div className="relative">
                <img 
                  src="/image.png" 
                  alt="Profile Avatar" 
                  className="w-16 h-16 rounded-full shadow-lg object-cover"
                />
                <div className="absolute -bottom-0.5 -right-0.5 w-5 h-5 bg-green-500 rounded-full border-2 border-gray-800"></div>
              </div>
              <div className="text-left">
                <h1 className="text-2xl font-bold text-white">
                  _knowek_
                </h1>
                <p className="text-green-400 text-sm">Online</p>
              </div>
            </div>
            
            {/* Social Media Buttons */}
            <div className="flex flex-col space-y-6 w-full">
              <button 
                onClick={handleTikTokClick}
                className="flex items-center justify-center gap-3 px-8 py-4 bg-gradient-to-r from-pink-500 to-red-600 text-white rounded-xl font-semibold hover:from-pink-600 hover:to-red-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
              >
                <div className="w-5 h-5 bg-black rounded-full flex items-center justify-center">
                  <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/>
                  </svg>
                </div>
                TikTok
              </button>
              
              <button className="flex items-center justify-center gap-3 px-8 py-4 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-xl font-semibold hover:from-pink-600 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg">
                <Instagram className="w-5 h-5" />
                Instagram
              </button>
              
              <button 
                onClick={handleDiscordClick}
                className="flex items-center justify-center gap-3 px-8 py-4 bg-gradient-to-r from-indigo-500 to-blue-600 text-white rounded-xl font-semibold hover:from-indigo-600 hover:to-blue-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
                </svg>
                Discord
              </button>
            </div>
            
            {/* Contact Info */}
            <div className="text-center text-gray-300 text-sm">
              <p>chcesz współpracować napisz na maila</p>
              <p className="text-gray-400 mt-1">wspolpracaknowek@gmail.com</p>
            </div>
          </div>
        </div>
      </div>

      {/* Second section - About Me */}
      <div id="about-section" className="relative z-10 min-h-screen flex items-center justify-center p-8">
        <div className="bg-gray-800/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-gray-700/50 p-12 max-w-2xl w-full">
          <div className="flex flex-col space-y-6">
            <h2 className="text-3xl font-bold text-white text-center mb-8">
              O mnie
            </h2>
            
            <div className="text-gray-300 space-y-4 leading-relaxed">
              <p className="text-lg">
                Cześć! Jestem twórcą treści znanym jako <span className="text-white font-semibold">_knowek_</span>. 
                Pasjonuję się tworzeniem angażujących i edukacyjnych treści, które łączą rozrywkę z wiedzą.
              </p>
              
              <p>
                <span className="text-yellow-400 font-semibold">Dopiero zaczynam swoją przygodę</span> jako twórca, 
                ale już teraz <span className="text-green-400 font-semibold">zaufało mi kilkanaście osób</span>, 
                które doceniają jakość i autentyczność moich treści.
              </p>
              
              <p>
                <span className="text-emerald-400 font-semibold">Jestem budowniczym w Minecraft</span> - 
                tworzę niesamowite budowle i dzielę się swoimi projektami ze społecznością. 
                Minecraft to nie tylko gra, ale prawdziwa platforma do wyrażania kreatywności!
              </p>
              
              <p>
                Na moich kanałach znajdziesz różnorodne treści - od ciekawostek i faktów, 
                przez eksperymenty i wyzwania, aż po edukacyjne materiały przedstawione w przystępny sposób.
              </p>
              
              <p>
                Moim celem jest inspirowanie innych do nauki i odkrywania świata w sposób, 
                który jest zarówno zabawny, jak i pouczający. Wierzę, że wiedza powinna być dostępna dla każdego.
              </p>
              
              <div className="bg-gray-700/50 rounded-lg p-6 mt-8">
                <h3 className="text-xl font-semibold text-white mb-4">Co robię?</h3>
                <ul className="space-y-2 text-gray-300">
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-pink-500 rounded-full"></span>
                    Tworzę treści edukacyjne na TikTok
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-purple-500 rounded-full"></span>
                    Dzielę się ciekawostkami na Instagram
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                    Buduję społeczność na Discord
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
                    Tworzę epickie budowle w Minecraft
                  </li>
                </ul>
              </div>
              
              <div className="bg-gradient-to-r from-green-500/20 to-yellow-500/20 rounded-lg p-4 mt-6 border border-green-500/30">
                <p className="text-center text-white font-medium">
                  🌟 Każde nowe zaufanie motywuje mnie do dalszego rozwoju! 🌟
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Third section - Reviews */}
      <div id="reviews-section" className="relative z-10 min-h-screen flex items-center justify-center p-8">
        <div className="max-w-6xl w-full">
          <h2 className="text-4xl font-bold text-white text-center mb-12">
            Opinie
          </h2>
          
          {/* Reviews carousel container */}
          <div className="relative">
            {/* Left arrow */}
            {canGoPrev && (
              <button
                onClick={prevReviews}
                className="absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-4 z-10 bg-gray-800/95 backdrop-blur-sm border border-gray-700/50 rounded-full p-3 text-white hover:bg-gray-700/95 transition-all duration-300 shadow-lg hover:scale-110"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
            )}
            
            {/* Right arrow */}
            {canGoNext && (
              <button
                onClick={nextReviews}
                className="absolute right-0 top-1/2 transform -translate-y-1/2 translate-x-4 z-10 bg-gray-800/95 backdrop-blur-sm border border-gray-700/50 rounded-full p-3 text-white hover:bg-gray-700/95 transition-all duration-300 shadow-lg hover:scale-110"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            )}
            
            {/* Reviews grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 transition-all duration-500">
              {getCurrentReviews().map((review, index) => (
                <div key={`${currentReviewIndex}-${index}`} className="bg-gray-800/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-gray-700/50 p-8 transform hover:scale-105 transition-all duration-300">
                  <div className="flex flex-col space-y-4">
                    {/* Rating stars */}
                    <div className="flex space-x-1">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    
                    {/* Review text */}
                    <p className="text-gray-300 leading-relaxed">
                      "{review.comment}"
                    </p>
                    
                    {/* Author info */}
                    <div className="flex items-center justify-between pt-4 border-t border-gray-700/50">
                      <div>
                        <p className="text-white font-semibold">{review.name}</p>
                        <p className="text-gray-400 text-sm">{review.date}</p>
                      </div>
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold text-sm">
                          {review.name.charAt(0)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Page indicators */}
            <div className="flex justify-center mt-8 space-x-2">
              {[...Array(totalPages)].map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentReviewIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentReviewIndex
                      ? 'bg-white'
                      : 'bg-gray-600 hover:bg-gray-500'
                  }`}
                />
              ))}
            </div>
          </div>
          
          {/* Call to action - Updated with single button */}
          <div className="text-center mt-12">
            <div className="bg-gray-800/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-gray-700/50 p-8 max-w-md mx-auto">
              <h3 className="text-xl font-semibold text-white mb-4">
                Podziel się swoją opinią!
              </h3>
              <p className="text-gray-300 mb-6">
                Jeśli podobają Ci się moje treści, zostaw swoją opinię.
              </p>
              <button 
                onClick={handleOpinionClick}
                className="px-8 py-3 bg-gradient-to-r from-green-500 to-blue-600 text-white rounded-xl font-semibold hover:from-green-600 hover:to-blue-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
              >
                Opinia
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Fourth section - FAQ */}
      <div id="faq-section" className="relative z-10 min-h-screen flex items-center justify-center p-8">
        <div className="max-w-4xl w-full">
          <h2 className="text-4xl font-bold text-white text-center mb-4">
            Najczęściej zadawane <span className="text-blue-400">pytania</span>
          </h2>
          
          <div className="space-y-6 mt-12">
            {faqData.map((faq, index) => (
              <div key={index} className="bg-gray-800/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-gray-700/50 overflow-hidden">
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full px-8 py-6 text-left flex items-center justify-between hover:bg-gray-700/30 transition-all duration-300"
                >
                  <span className="text-lg font-medium text-gray-300 pr-4">
                    {faq.question}
                  </span>
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                    {expandedFAQ === index ? (
                      <ChevronUp className="w-5 h-5 text-white" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-white" />
                    )}
                  </div>
                </button>
                
                {expandedFAQ === index && (
                  <div className="px-8 pb-6 border-t border-gray-700/30">
                    <div className="pt-4 text-gray-300 leading-relaxed">
                      {faq.answer}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
          
          {/* Contact section */}
          <div className="text-center mt-12">
            <div className="bg-gray-800/95 backdrop-blur-sm rounded-2xl shadow-2xl border border-gray-700/50 p-8 max-w-md mx-auto">
              <h3 className="text-xl font-semibold text-white mb-4">
                Masz inne pytanie?
              </h3>
              <p className="text-gray-300 mb-6">
                Jeśli nie znalazłeś odpowiedzi na swoje pytanie, napisz do mnie!
              </p>
              <button 
                onClick={handleContactClick}
                className="inline-block px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl font-semibold hover:from-blue-600 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
              >
                Napisz maila
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Floating cosmic particles - fixed */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="cosmic-particle"></div>
        <div className="cosmic-particle delay-1000"></div>
        <div className="cosmic-particle delay-2000"></div>
        <div className="cosmic-particle delay-3000"></div>
      </div>
    </div>
  );
}

export default App;